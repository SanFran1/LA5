# labAssignment_5

Build: gcc lab_assignment_5.c
